import  init from './js/geonameApi.js'
import './styles/_index.css';

init();