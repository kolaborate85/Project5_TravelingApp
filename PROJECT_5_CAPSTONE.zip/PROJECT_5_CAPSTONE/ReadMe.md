TRAVELING APP
This app contains a router, server, a frontend file, along with css folders
webpack development and production files are includes to help us configure dependencies 
The APIs are configure inside the router.js file for security purpose
